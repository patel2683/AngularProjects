import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

import {MaterialModule} from './modules/material-ui.module';
import {ReactiveFormsModule} from '@angular/forms';
import {FormsModule} from '@angular/forms';
import { HeaderPate3193Component } from './header-pate3193/header-pate3193.component';
import { FooterPate3193Component } from './footer-pate3193/footer-pate3193.component';
import { BooksPate3193Component } from './books-pate3193/books-pate3193.component';
import { CampusPate3193Component } from './campus-pate3193/campus-pate3193.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderPate3193Component,
    FooterPate3193Component,
    BooksPate3193Component,
    CampusPate3193Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [
    provideClientHydration(),
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
