import { Component, Input } from '@angular/core';
import { A2Personal } from '../pate3193interface';

@Component({
  selector: 'app-header-pate3193',
  templateUrl: './header-pate3193.component.html',
  styleUrls: ['./header-pate3193.component.css']
})
export class HeaderPate3193Component {

  @Input() pate3193MyData!: A2Personal;
}

