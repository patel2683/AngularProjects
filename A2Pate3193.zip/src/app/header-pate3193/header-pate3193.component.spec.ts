import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderPate3193Component } from './header-pate3193.component';

describe('HeaderPate3193Component', () => {
  let component: HeaderPate3193Component;
  let fixture: ComponentFixture<HeaderPate3193Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HeaderPate3193Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HeaderPate3193Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
