export class Header{
    pate3193Name! :String;
    pate3193ID! :String;
}
export class Footer{
    pate3193Email! :String;
    pate3193Program! :String;
}