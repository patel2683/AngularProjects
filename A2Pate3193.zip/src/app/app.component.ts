import { Component } from '@angular/core';
import { A2Personal, MyBook, CampusData } from './pate3193interface'; 
import Assignment02Data from   '../assets/data/Assignment02.json'; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'A2Pate3193';

  pate3193Personal: A2Personal = Assignment02Data.a2Personal;
  pate3193Books: MyBook[] = Assignment02Data.myBooks;
  pate3193Campus: CampusData[] = Assignment02Data.campusData;
  
}
