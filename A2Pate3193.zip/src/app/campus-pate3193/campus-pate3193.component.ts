import { Component,Input } from '@angular/core';
import { CampusData } from '../pate3193interface';

@Component({
  selector: 'app-campus-pate3193',
  templateUrl: './campus-pate3193.component.html',
  styleUrl: './campus-pate3193.component.css'
})
export class CampusPate3193Component {

  @Input() campusData991631378!: CampusData[]; 
  selectedCampusAddress: string = '';

  onSelectCampus(campusName: string) {
    const selectedCampus = this.campusData991631378.find(campus => campus.campus === campusName);
    if (selectedCampus) {
      this.selectedCampusAddress = `Address: ${selectedCampus.street}, ${selectedCampus.city}`;
    }
  }

}
