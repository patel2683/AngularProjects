import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CampusPate3193Component } from './campus-pate3193.component';

describe('CampusPate3193Component', () => {
  let component: CampusPate3193Component;
  let fixture: ComponentFixture<CampusPate3193Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CampusPate3193Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CampusPate3193Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
