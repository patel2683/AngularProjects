import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FooterPate3193Component } from './footer-pate3193.component';

describe('FooterPate3193Component', () => {
  let component: FooterPate3193Component;
  let fixture: ComponentFixture<FooterPate3193Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FooterPate3193Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(FooterPate3193Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
