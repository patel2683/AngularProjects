import { Component,Input } from '@angular/core';
import { A2Personal } from '../pate3193interface';

@Component({
  selector: 'app-footer-pate3193',
  templateUrl: './footer-pate3193.component.html',
  styleUrl: './footer-pate3193.component.css'
})
export class FooterPate3193Component {

  @Input() pate3193MyData!: A2Personal;
}
