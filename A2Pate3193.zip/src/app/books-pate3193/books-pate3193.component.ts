import { Component,Input} from '@angular/core';
import { MyBook } from '../pate3193interface';

@Component({
  selector: 'app-books-pate3193',
  templateUrl: './books-pate3193.component.html',
  styleUrl: './books-pate3193.component.css'
})
export class BooksPate3193Component {
  
  @Input() myBooks99163378!: MyBook[];
  displayedColumns: string[] =["authorName", "bookTitle", "published"];


}
