import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BooksPate3193Component } from './books-pate3193.component';

describe('BooksPate3193Component', () => {
  let component: BooksPate3193Component;
  let fixture: ComponentFixture<BooksPate3193Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BooksPate3193Component]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BooksPate3193Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
