import { Component } from '@angular/core';
import { Midterm } from './pate3193Class';
import mtExam from '../assets/data/mtExam.json';
import { Exam } from './pate3193interface'; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'pate3193MTExam';
  
  pate3193Personal: Midterm = {LASTypate3193:'Patel',FIRSTpate3193: 'Henil', IDpate3193:'991631378', LOGINpate3193:'pate3193'};
  pate3193JSON: Exam[] = mtExam.LifeCycles;
}
