export class Midterm {
    LASTypate3193!: string;
    FIRSTpate3193!: string;
    IDpate3193!: string;
    LOGINpate3193!: string;

}