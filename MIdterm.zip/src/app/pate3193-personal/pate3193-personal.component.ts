import { Component,Input } from '@angular/core';
import { Midterm } from '../pate3193Class';

@Component({
  selector: 'app-pate3193-personal',
  templateUrl: './pate3193-personal.component.html',
  styleUrl: './pate3193-personal.component.css'
})
export class Pate3193PersonalComponent {
  @Input() pate3193Child!: Midterm;
}
