import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pate3193PersonalComponent } from './pate3193-personal.component';

describe('Pate3193PersonalComponent', () => {
  let component: Pate3193PersonalComponent;
  let fixture: ComponentFixture<Pate3193PersonalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Pate3193PersonalComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Pate3193PersonalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
