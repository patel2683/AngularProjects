export interface Exam {
    hook: string;
    purpose: string;
    timing: string;
  }