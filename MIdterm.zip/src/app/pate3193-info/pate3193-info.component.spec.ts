import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Pate3193InfoComponent } from './pate3193-info.component';

describe('Pate3193InfoComponent', () => {
  let component: Pate3193InfoComponent;
  let fixture: ComponentFixture<Pate3193InfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Pate3193InfoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Pate3193InfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
