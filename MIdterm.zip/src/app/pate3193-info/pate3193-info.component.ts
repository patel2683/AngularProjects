import { Component,Input } from '@angular/core';
import { Exam } from '../pate3193interface';

@Component({
  selector: 'app-pate3193-info',
  templateUrl: './pate3193-info.component.html',
  styleUrl: './pate3193-info.component.css'
})
export class Pate3193InfoComponent {
  @Input() pate3193List! : Exam[] ;
}
